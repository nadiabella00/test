<h2>Appointment Has Been Booked</h2>
<br>
<div>
  <ul>
    <li>User Name: {{$data['name']}}</li>
    <br>
    <li>User Email: {{$data['email']}}</li>
    <br>
    <li>Washing Plan: {{$data['washing_plan']}}</li>
    <br>
    <li>Vehicle Company: {{$data['vehicle_company']}}</li>
    <br>
    <li>Vehicle modal: {{$data['vehicle_modal']}}</li>
    <br>
    <li>Vehicle type: {{$data['vehicle_type']}}</li>
    <br>
    <li>Appointment Date: {{$data['date']}}</li>
    <br>
    <li>vehicle number: {{$data['vehicle_no']}}</li>
    <br>
    <li>Time frame: {{$data['time_frame']}}</li>
  </ul>
</div>
